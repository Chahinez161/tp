package com.chahinez.diplome.restcontrollers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.chahinez.diplome.entities.Diplome;
import com.chahinez.diplome.service.DiplomeService;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class DiplomeRESTController {
@Autowired
DiplomeService diplomeService;
@RequestMapping(method = RequestMethod.GET)
public List<Diplome> getAllDiplomes() {
return diplomeService.getAllDiplomes();
}
@RequestMapping(value="/{id}",method = RequestMethod.GET)
public Diplome getDiplomesById(@PathVariable("id") Long id) {
return diplomeService.getDiplome(id);
 }
@RequestMapping(method = RequestMethod.POST)
public Diplome createDiplome(@RequestBody Diplome diplome) {
return diplomeService.saveDiplome(diplome);
}
@RequestMapping(method = RequestMethod.PUT)
public Diplome updateDiplome(@RequestBody Diplome diplome) {
return diplomeService.updateDiplome(diplome);
}
@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
public void deleteDiplome(@PathVariable("id") Long id)
{
diplomeService.deleteDiplomeById(id);
}
@RequestMapping(value="/prodscat/{idCat}",method = RequestMethod.GET)
public List<Diplome> getDiplomesByCatId(@PathVariable("idCat") Long idCat) {
return diplomeService.findByFaculteeIdFacultee(idCat);
}
@RequestMapping(path = "all",method = RequestMethod.GET)
public List<Diplome> getAllDiplomes1() {
return diplomeService.getAllDiplomes();
}
}
