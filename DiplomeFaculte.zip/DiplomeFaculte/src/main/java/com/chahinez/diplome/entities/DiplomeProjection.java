package com.chahinez.diplome.entities;

import org.springframework.data.rest.core.config.Projection;
@Projection(name = "nomDiplome", types = { Diplome.class })
public interface DiplomeProjection {
public String getNomDiplome();
}
